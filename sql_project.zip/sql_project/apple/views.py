from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def home(request):
    return render(request,'home.html')
def index(request):
    return render(request,'SQL.html')
def select(request):
    return render(request,'select.html')
def where(request):
    return render(request,'where.html')
def and_or_not(request):
    return render(request,'and_or_not.html')
def orderby(request):
    return render(request,'orderby.html')
def like(request):
    return render(request,'like.html')
def insert(request):
    return render(request,'insert.html')
def update(request):
    return render(request,'update.html')
def delete(request):
    return render(request,'delete.html')
def between(request):
    return render(request,'between.html')
def joins(request):
    return render(request,'joins.html')
def primarykey(request):
    return render(request,'primary_key.html')
def foreignkey(request):
    return render(request,'foreign_key.html')
def programs(request):
    return render(request,'programs.html')
def factorial(request):
    return render(request,'factorial.html')
def palindrome(request):
    return render(request,'palindrome.html')
def primnumber(request):
    return render(request,'primnumber.html')
def oddoreven(request):
    return render(request,'oddoreven.html')
def recursion(request):
    return render(request,'recursion.html')
def fibonacci(request):
    return render(request,'fibonacci.html')
def inheritance(request):
    return render(request,'inheritance.html')
def polymorphism(request):
    return render(request,'polymorphism.html')
def abstraction(request):
    return render(request,'abstraction.html')
def sorting(request):
    return render(request,'sorting.html')
def slicing(request):
    return render(request,'slicing.html')
    