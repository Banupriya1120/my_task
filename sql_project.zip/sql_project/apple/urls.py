"""
URL configuration for sql_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from.views import*
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',home),
    path('SQL',index),
    path('home',home),
    path('select_1',select),
    path('where_1',where),
    path('and-or-not',and_or_not),
    path('order_by',orderby),
    path('Like_1',like),
    path('insert_1',insert),
    path('update_1',update),
    path('delete_1',delete),
    path('Between_',between),
    path('joins_1',joins),
    path('Primary_key',primarykey),
    path('foreign_key',foreignkey),
    path('py-programs',programs),
    path('factorial_',factorial),
    path('polindrome_',palindrome),
    path('prime_number',primnumber),
    path('odd_even',oddoreven),
    path('recursion_',recursion),
    path('fibonacci_',fibonacci),
    path('inheritance_',inheritance),
    path('polymorphism_',polymorphism),
    path('abstraction_',abstraction),
    path('sorting_',sorting),
    path('slicing_',slicing)

    
]
