from django.shortcuts import render
from django.http import HttpResponse



# Create your views here.

def hom(request):
    return render(request,'home.html')
def program(request):
    return render(request,'all_program.html')
def theories(request):
    return render(request,'py_theories.html')
def methods(request):
    return render(request,'py_methods.html')

def program1(request):
    return render(request,'program_1.html')

def program2(request):
    return render(request,'program_2.html')
def program3(request):
    return render(request,'program_3.html')
def program4(request):
    return render(request,'program_4.html')
def program5(request):
    return render(request,'program_5.html')
def program6 (request):
    return render(request,'program_6.html')
def program7(request):
    return render(request,'program_7.html')
def program8(request):
    return render(request,'program_8.html')
def program9(request):
    return render(request,'program_9.html')
def program10(request):
    return render(request,'program_10.html')
def program11(request):
    return render(request,'program_11.html')
def program12(request):
    return render(request,'program_12.html')
def program13(request):
    return render(request,'program_13.html')
def program14(request):
    return render(request,'program_14.html')
def program15(request):
    return render(request,'program_15.html')
def program16(request):
    return render(request,'program_16.html')
def program17(request):
    return render(request,'program_17.html')
def program18(request):
    return render(request,'program_18.html')
def program19(request):
    return render(request,'program_19.html')
def program20(request):
    return render(request,'program_20.html')
def program21(request):
    return render(request,'program_21.html')
def program22(request):
    return render(request,'program_22.html')
def program23(request):
    return render(request,'program_23.html')
def program24(request):
    return render(request,'program_24.html')
def list(request):
    return render(request,'list_methods.html')
def set(request):
    return render(request,'set_methods.html')
def string(request):
    return render(request,'str_methods.html')
def dict(request):
    return render(request,'dict_methods.html')
def pep_8(request):
    return render(request,'pep_8.html')
def list_tuple(request):
    return render(request,'list_tuple.html')
def listandset(request):
    return render(request,'list_set.html')
def dictandset(request):
    return render(request,'dict_set.html')
def datatype1(request):
    return render(request,'datatype.html')

def self_(request):
    return render(request,'self.html')
def in_it(request):
    return render(request,'init.html')
def slicing_(request):
    return render(request,'slicing.html')
def memory(request):
    return render(request,'memory.html')
def split_join(request):
    return render(request,'split_join.html')
def arrays_list(request):
    return render(request,'arrays_list.html')
def laambda(request):
    return render(request,'laambda.html')
def shallow_deep(request):
    return render(request,'shallow_deep.html')
def pickling_unpickling(request):
    return render(request,'pickling_unpickling.html')
def geneator_python(request):
    return render(request,'geneator_python.html')
def oops_py(request):
    return render(request,'oops_py.html')
def key_fetures(request):
    return render(request,'key_fetures.html')
def py_modules(request):
    return render(request,'py_modules.html')
def py_function(request):
    return render(request,'py_function.html')
def doc_string(request):
    return render(request,'doc_string.html')




   