"""
URL configuration for python_tips project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from.views import*
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',hom),
    path('home',hom),
    path('py-theories',theories),
    path('py-methods',methods),
    path('programs',program),
    path('program-1',program1),
    path('program-2',program2),
    path('program-3',program3),
    path('program-4',program4),
    path('program-5',program5),
    path('program-6',program6),
    path('program-7',program7),
    path('program-8',program8),
    path('program-9',program9),
    path('program-10',program10),
    path('program-11',program11),
    path('program-12',program12),
    path('program-13',program13),
    path('program-14',program14),
    path('program-15',program15),
    path('program-16',program16),
    path('program-17',program17),
    path('program-18',program18),
    path('program-19',program19),
    path('program-20',program20),
    path('program-21',program21),
    path('program-22',program22),
    path('program-23',program23),
    path('program-24',program24),
    path('list-methods',list),
    path('set-methods',set),
    path('str-methods',string),
    path('dict-methods',dict),
    path('pep-8',pep_8),
    path('list-tuple',list_tuple),
    path('list-set',listandset),
    path('dict-set',dictandset),
    path('datatypes',datatype1),
    path('self-',self_),
    path('in-it',in_it),
    path('slicing',slicing_),
    path('memory-management',memory),
    path('split-join',split_join),
    path('arrays-list',arrays_list),
    path('lambda-',laambda),
    path('shallow',shallow_deep),
    path('pickling-',pickling_unpickling),
    path('geneator-',geneator_python),
    path('oops-',oops_py),
    path('key-feature',key_fetures),
    path('modules',py_modules),
    path('functions',py_function),
    path('doc-string',doc_string)
    
]   
